# YONI VIDEO DOWNLOADER BOT

## 1) ፋይሎች
- `main.py` — Telegram webhook እና የማውረድ ሂደት
- `requirements.txt` — Python packages
- `apt.txt` — FFmpeg መጫኛ
- `render.yaml` — Render ማዋቀሪያ

## 2) አስፈላጊ ማስታወሻ
የሊንክ መረጃ በጊዜያዊ የRAM ማህደር ይቀመጣል። Render እንደገና ከተነሳ ወይም ከተዘጋ የተጠበቁ ሊንኮች ይጠፋሉ።

## 3) Render
1. GitHub ላይ አዲስ repository ይፍጠሩ።
2. እነዚህን ፋይሎች ይጫኑ።
3. Render → New → Web Service → GitHub repository ይምረጡ።
4. `BOT_TOKEN` Environment Variable ውስጥ BotFather የሰጠውን token ያስገቡ።
5. Deploy ያድርጉ።

## 4) ገደቦች
Render Free ከ15 ደቂቃ የውጭ HTTP ጥያቄ ካልደረሰው ይተኛል፤ እንዲሁም የፋይል ስርዓቱ ephemeral ነው። ስለዚህ 24/7 የማይቋረጥ አገልግሎት አይደለም።
