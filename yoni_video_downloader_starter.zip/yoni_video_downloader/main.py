import os
import re
import uuid
import threading
import tempfile
import shutil
import logging
from urllib.parse import urlparse

import requests
import yt_dlp
from flask import Flask, request, jsonify

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("yoni-bot")

TOKEN = os.environ["BOT_TOKEN"]
PUBLIC_URL = os.environ["RENDER_EXTERNAL_URL"].rstrip("/")
API = f"https://api.telegram.org/bot{TOKEN}"
MAX_UPLOAD = 48 * 1024 * 1024  # leave room below Telegram's 50 MB Bot API upload limit

app = Flask(__name__)
session = requests.Session()
LINKS = {}  # temporary in-memory link store; cleared on service restart

ALLOWED_HOSTS = {
    "youtube.com", "www.youtube.com", "m.youtube.com", "youtu.be",
    "tiktok.com", "www.tiktok.com", "vm.tiktok.com", "vt.tiktok.com"
}

def tg(method, data=None, files=None, timeout=60):
    response = session.post(f"{API}/{method}", data=data, files=files, timeout=timeout)
    response.raise_for_status()
    result = response.json()
    if not result.get("ok"):
        raise RuntimeError(result.get("description", "Telegram API error"))
    return result.get("result")

def valid_url(url):
    try:
        parsed = urlparse(url)
        host = (parsed.hostname or "").lower()
        return parsed.scheme in ("http", "https") and any(
            host == domain or host.endswith("." + domain) for domain in ALLOWED_HOSTS
        )
    except Exception:
        return False

def main_menu(chat_id):
    tg("sendMessage", {
        "chat_id": chat_id,
        "text": (
            "👋 እንኳን ወደ YONI VIDEO DOWNLOADER በደህና መጡ!\n\n"
            "የYouTube ወይም TikTok ሊንክ ይላኩ።\n"
            "ከዚያ የቪዲዮ ጥራት ወይም MP3 ይምረጡ።"
        )
    })

def show_options(chat_id, url):
    link_id = uuid.uuid4().hex[:10]
    LINKS[link_id] = {"url": url, "chat_id": chat_id}
    keyboard = [
        [
            {"text": "🎬 1080p", "callback_data": f"dl|{link_id}|1080"},
            {"text": "🎬 720p", "callback_data": f"dl|{link_id}|720"},
        ],
        [
            {"text": "🎬 480p", "callback_data": f"dl|{link_id}|480"},
            {"text": "🎬 360p", "callback_data": f"dl|{link_id}|360"},
        ],
        [{"text": "🎵 MP3 Audio", "callback_data": f"dl|{link_id}|mp3"}],
    ]
    tg("sendMessage", {
        "chat_id": chat_id,
        "text": "✅ ሊንኩ ተቀብያለሁ።\nየምትፈልጉትን ጥራት ይምረጡ፦",
        "reply_markup": {"inline_keyboard": keyboard}
    })

def extract_and_send(chat_id, url, choice, message_id):
    workdir = tempfile.mkdtemp(prefix="yoni_")
    try:
        tg("sendMessage", {"chat_id": chat_id, "text": "⏳ ቪዲዮውን እያዘጋጀሁ ነው..."})
        if choice == "mp3":
            fmt = "bestaudio/best"
            postprocessors = [{
                "key": "FFmpegExtractAudio",
                "preferredcodec": "mp3",
                "preferredquality": "192",
            }]
            output_type = "audio"
        else:
            height = int(choice)
            fmt = (
                f"bestvideo[height<={height}]+bestaudio/"
                f"best[height<={height}][ext=mp4]/"
                f"best[height<={height}]/best"
            )
            postprocessors = []
            output_type = "video"

        opts = {
            "format": fmt,
            "outtmpl": os.path.join(workdir, "%(title).80s-%(id)s.%(ext)s"),
            "noplaylist": True,
            "quiet": True,
            "no_warnings": True,
            "max_filesize": MAX_UPLOAD,
            "merge_output_format": "mp4",
            "postprocessors": postprocessors,
            "socket_timeout": 20,
            "retries": 2,
        }

        with yt_dlp.YoutubeDL(opts) as ydl:
            info = ydl.extract_info(url, download=True)
            filename = ydl.prepare_filename(info)
            if output_type == "audio":
                filename = os.path.splitext(filename)[0] + ".mp3"
            if not os.path.exists(filename):
                # yt-dlp may change the extension after merging/post-processing
                candidates = [
                    os.path.join(workdir, f) for f in os.listdir(workdir)
                    if os.path.isfile(os.path.join(workdir, f))
                ]
                if not candidates:
                    raise RuntimeError("የወረደው ፋይል አልተገኘም።")
                filename = max(candidates, key=os.path.getsize)

        size = os.path.getsize(filename)
        if size > MAX_UPLOAD:
            raise RuntimeError("ፋይሉ ከTelegram የመላኪያ ገደብ በላይ ነው። ዝቅተኛ ጥራት ይምረጡ።")

        title = (info.get("title") or "Downloaded media")[:900]
        with open(filename, "rb") as media:
            if output_type == "audio":
                tg("sendAudio", {"chat_id": chat_id, "title": title[:250]}, files={"audio": media}, timeout=180)
            else:
                tg("sendVideo", {"chat_id": chat_id, "caption": title[:900], "supports_streaming": "true"},
                   files={"video": media}, timeout=180)

    except Exception as exc:
        log.exception("Download failed")
        msg = str(exc)
        if "max-filesize" in msg.lower() or "file is larger" in msg.lower():
            msg = "ፋይሉ ትልቅ ነው። 360p ወይም 480p ይሞክሩ።"
        tg("sendMessage", {"chat_id": chat_id, "text": f"❌ ማውረድ አልተሳካም።\n{msg[:700]}"})
    finally:
        shutil.rmtree(workdir, ignore_errors=True)

def process_update(update):
    if "message" in update:
        msg = update["message"]
        chat_id = msg["chat"]["id"]
        text = (msg.get("text") or "").strip()
        if text.startswith("/start") or text.startswith("/help"):
            main_menu(chat_id)
        elif valid_url(text):
            show_options(chat_id, text)
        else:
            tg("sendMessage", {
                "chat_id": chat_id,
                "text": "⚠️ እባክዎ ትክክለኛ የYouTube ወይም TikTok ሊንክ ብቻ ይላኩ።"
            })

    elif "callback_query" in update:
        query = update["callback_query"]
        data = query.get("data", "")
        tg("answerCallbackQuery", {"callback_query_id": query["id"]})
        parts = data.split("|")
        if len(parts) != 3 or parts[0] != "dl":
            return
        link_id, choice = parts[1], parts[2]
        saved = LINKS.pop(link_id, None)
        if not saved:
            chat_id = query.get("message", {}).get("chat", {}).get("id")
            if chat_id:
                tg("sendMessage", {"chat_id": chat_id, "text": "⚠️ ሊንኩ ጊዜው አልፎበታል። እባክዎ ሊንኩን እንደገና ይላኩ።"})
            return
        threading.Thread(
            target=extract_and_send,
            args=(saved["chat_id"], saved["url"], choice, None),
            daemon=True
        ).start()

@app.route("/", methods=["GET"])
def health():
    return "YONI Video Downloader is running", 200

@app.route("/telegram-webhook", methods=["POST"])
def webhook():
    update = request.get_json(silent=True) or {}
    # Return quickly so Telegram does not keep the webhook request open.
    threading.Thread(target=process_update, args=(update,), daemon=True).start()
    return jsonify({"ok": True})

@app.route("/set-webhook", methods=["GET"])
def set_webhook():
    result = tg("setWebhook", {"url": f"{PUBLIC_URL}/telegram-webhook"})
    return jsonify(result)

if __name__ == "__main__":
    port = int(os.environ.get("PORT", "10000"))
    # Set the webhook once when the service starts.
    try:
        tg("setWebhook", {"url": f"{PUBLIC_URL}/telegram-webhook"})
    except Exception:
        log.exception("Could not set webhook")
    app.run(host="0.0.0.0", port=port)
